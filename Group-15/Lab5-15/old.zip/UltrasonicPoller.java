import java.util.ArrayList;
import java.util.List;

import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.UltrasonicSensor;
import lejos.nxt.comm.RConsole;
import lejos.util.TimerListener;
import lejos.util.Timer;

/**
 * 
 * @project Lab 5 Object Recognition 
 * @names Riley van Ryswyk & Aditya Saha
 * @studentID 260447357 & 260453165
 * @group 15
 * @course ECSE 211 
 * @date 10/10/2013
 * 
 * Class for interaction with ultrasonic sensor
 * 
 */
public class UltrasonicPoller implements TimerListener {

	private UltrasonicSensor us;
	
	//period to Update Ultrasonic sensor in ms
	private final int PERIOD = 35;
	
	// Store list of previous ultrasonic sensor values for filtering
	private List<Integer> usValues = new ArrayList<Integer>();
	
	private NXTRegulatedMotor usMotor;
	
	private Odometer odo;
	
	private Timer usTimer;
	
	// True if we are polling the ultrasonic sensor once a period
	private boolean started;
	
	private Object lock;
	
	/**
	 * UltrasonicPoller constructor
	 * @param us
	 * @param usMotor
	 * @param odo
	 */
	public UltrasonicPoller(UltrasonicSensor us, NXTRegulatedMotor usMotor, Odometer odo) {
		this.us = us;
		this.usTimer = new Timer(PERIOD, this);
		this.started = false;
		this.lock = new Object();
		this.usMotor = usMotor;
		this.odo = odo;
		
		//limit usMotor acceleration
		usMotor.setAcceleration(1000);
		//stop continuous mode of Ultrasonic sensor
		us.off();
		
	}
	
	/**
	 * Called once a period when started
	 * calls pingUS()
	 */
	public void timedOut() {
		pingUS();		
	}
	
	/**
	 * Pings ultrasonic sensor and records the result
	 */
	public void pingUS() {
		int distance;
		
		// do a ping
		us.ping();
		
		// wait for the ping to complete
		try { Thread.sleep(30); } catch (InterruptedException e) {}
		
		// there will be a delay here
		distance = us.getDistance();

		synchronized (lock) {
		
			if(usValues.size() > 4) { 
				//remove the oldest one
				usValues.remove(0);
			}
			
			//add the current value to array of values
			usValues.add(distance);
		}
	}
	
	public void start() {
		if(!started) {
			usTimer.start(); 
			this.started = true;
		}
	}
	
	public void stop() {
		if(started) {
			usTimer.stop();
			this.started = false;
		}
	}
	
	public void clear() {
		usValues.clear();
	}
	
	public int scan() {
		stop();
		
		synchronized (lock) {
			usValues.clear();			
		}
		
		pingUS();
		pingUS();
		pingUS();
		pingUS();
		pingUS();
		
		return filterUS();
		
	}
	
	public void triScan(int[] data, int offset) {
		
		double[] pos = new double[3];

		odo.getPosition(pos);
		
		//Stores the x, y, average heading of scan
		data[0 + offset] = (int) pos[0];
		data[1 + offset] = (int) pos[1];
		data[2 + offset] = 90;
		
		rotateUS(107);
		data[3 + offset] = scan();
		rotateUS(90);
		data[4 + offset] = scan();
		rotateUS(73);
		data[5 + offset] = scan();
		
	}
	
	public void rotateUS(int heading) {
		
		int robotHeading = (int) odo.getTheta();
		
		// Change deltaTheta to [0,360)
		if (robotHeading > 180) {
			robotHeading -= 360;
		} 
		
		int rotateTo =  robotHeading - heading;
		if(rotateTo < -120) {
			rotateTo  = -120;
		} else if(rotateTo > 40) {
			rotateTo = 40;
		}
		
		usMotor.rotateTo(rotateTo);
		
	}
	
	
	public int filterUS() {
		//make sure we have sufficient number of samples
		if(usValues.size() >= 3) {
									
			int result;
			int size;
			List<Integer> usValuesSorted;
			
			synchronized (lock) {
				//array of sorted values
				usValuesSorted = new ArrayList<Integer>(usValues);
				
				//length of values (should be 5)
				size = usValuesSorted.size();
				
				//sort the values: lowest to highest
				for(int i=0; i<size; i++) {
					for(int j=i+1; j<size;j++) {
						if(usValuesSorted.get(i) > usValuesSorted.get(j)) {
							int temp = usValuesSorted.get(i);
							usValuesSorted.set(i, usValuesSorted.get(j));
							usValuesSorted.set(j, temp);					
						}
					}
				}
			}
			
			// if odd pick the middle value, else average the two middle values
			if(size % 2 == 1 ) {
				result = usValuesSorted.get(size/2);
			} else {
				result = ( usValuesSorted.get(size/2-1) + usValuesSorted.get(size/2) ) / 2;
			}

			//return result
			return result;
		} 
		//not enough data for filtering yet, so return the current value
		else {
			int result; 
			synchronized (lock) {
				if (usValues.size() > 0) {
					result = usValues.get(usValues.size()-1);
				} else {
					result = 256;
				}
			}
			
			return result;
		}
	}
	
	
}
