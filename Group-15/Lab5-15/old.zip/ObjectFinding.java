import java.util.ArrayList;

import lejos.nxt.Motor;
import lejos.nxt.comm.RConsole;


public class ObjectFinding {
	private UltrasonicPoller usPoller;
	private Odometer odo;
	private TwoWheeledRobot robot;
	private ObjectRecognitionTwo ort;
	private Navigation nav;
	private Grid grid;
	
	private ArrayList<Integer> points = new ArrayList<Integer>();
	private ArrayList<Integer> objects = new ArrayList<Integer>();
	
	private final int FIELD_WIDTH = 4; 
	private final int FIELD_LENGTH = 8;
	private final double TILE_SIZE = 30.48;
	private static final long UPDATE_PERIOD = 75;
	
	
	public ObjectFinding(UltrasonicPoller usPoller, Odometer odo, TwoWheeledRobot robot, ObjectRecognitionTwo ort, Grid grid) {
		this.usPoller = usPoller;
		this.odo = odo;
		this.robot = robot;
		this.ort = ort;
		this.nav = odo.getNavigation();
		this.grid = grid;
		nav.setGrid(grid);
		ort.setGrid(grid);
	}
	
	public void findStyrofoam() {
		initialScan();
		//analyzeScan(data);
		//RConsole.println(points.toString());
		usPoller.rotateUS(0);
		
		while(grid.contains((short) 6) && !ort.getHaveStyrofoam()) {
		
			while(grid.contains((short) 8) && !ort.getHaveStyrofoam()) {
				inspectClosestTile((short) 8);
				RConsole.println(grid.printGrid());
			}
			
			while(grid.contains((short) 7) && !ort.getHaveStyrofoam()) {
				inspectClosestTile((short) 7);
				RConsole.println(grid.printGrid());
			}
			
			scan();
		}
		RConsole.println("Done");
		//checkPoints();
		
	}
	
	public void initialScan() {
		
		nav.travelTo(-10, 40);
		nav.turnTo(0);
		usPoller.rotateUS(0);
		usPoller.pingUS();
		usPoller.pingUS();	
		usPoller.pingUS();	
		final int wall = usPoller.filterUS();
		
		usPoller.rotateUS(90);
		usPoller.clear();
		usPoller.start();
		
		ArrayList<Integer> peaks = new ArrayList<Integer>();
		
		int endPoint; 
		if(wall > 90) {
			endPoint = 68;
			(new Thread() {
				public void run() {
					nav.travelTo(70, 40);
				}
			}).start();
		} else {
			endPoint = wall-22;
			(new Thread() {
				public void run() {
					nav.travelTo(wall-20, 40);
				}
			}).start();
		}
	
		int usLastValue = 256;
		int usCurrentValue;
		double x = odo.getX();

		while (x < endPoint) {
			
			usCurrentValue = usPoller.filterUS();
			x = odo.getX();
			
			if(usLastValue != 256) {
				
				if(Math.abs(usCurrentValue - usLastValue) > 6) {
					peaks.add(usCurrentValue);
					peaks.add(usLastValue);
					peaks.add((int) x);
					peaks.add((int) odo.getY());
				}
				
			}
			
			usLastValue = usCurrentValue;
			
			try {
				Thread.sleep(35);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		RConsole.println(peaks.toString());
		analyzeScan2(peaks, -10, endPoint, 90);
		RConsole.println(grid.printGrid());
		
	}
	
	
	public void scan() {
		RConsole.println("Scanning");
		int[] tile = {(int)odo.getX(), (int)odo.getY()};
		
		grid.getClosestTile2(tile, (short) 6);
		
		RConsole.println( String.valueOf(tile[0]) + ";" + String.valueOf(tile[1]));
		
		final int y = grid.getY(tile[1]);
		
		
		nav.travelTo(grid.getX(tile[0]), y);
		nav.turnTo(0);
		RConsole.println("done travelling");
		usPoller.rotateUS(0);
		usPoller.pingUS();
		usPoller.pingUS();	
		usPoller.pingUS();	
		final int wall = usPoller.filterUS();
		
		usPoller.rotateUS(90);
		usPoller.clear();
		usPoller.start();
		
		ArrayList<Integer> peaks = new ArrayList<Integer>();
		
		int endPoint; 
		if(wall > 90) {
			endPoint = 68;
			(new Thread() {
				public void run() {
					nav.travelTo(70, y);
				}
			}).start();
		} else {
			endPoint = wall-28;
			(new Thread() {
				public void run() {
					nav.travelTo(wall-20, y);
				}
			}).start();
		}
	
		int usLastValue = 256;
		int usCurrentValue;
		double x = odo.getX();

		while (x < endPoint) {
			
			usCurrentValue = usPoller.filterUS();
			x = odo.getX();
			
			if(usLastValue != 256) {
				
				if(Math.abs(usCurrentValue - usLastValue) > 6) {
					peaks.add(usCurrentValue);
					peaks.add(usLastValue);
					peaks.add((int) x);
					peaks.add((int) odo.getY());
				}
				
			}
			
			usLastValue = usCurrentValue;
			
			try {
				Thread.sleep(35);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		RConsole.println(peaks.toString());
		grid.setTile(tile[0], tile[1], (short) 0);
		analyzeScan2(peaks, grid.getX(tile[0]), endPoint, 90);
		RConsole.println(grid.printGrid());
		
		
	}
	
	public void analyzeScan2(ArrayList<Integer> peaks, int start, int end, int heading) {
		int currentUS;
		int previousUS;
		int x;
		int y;
		int wallDistance;
		
		
		for(int i=0; i+3<peaks.size(); i+=4) {
			RConsole.println("analyzing");
			currentUS = peaks.get(i);
			previousUS = peaks.get(i+1);
			x = peaks.get(i+2);
			y = peaks.get(i+3);
			wallDistance = grid.distanceToWall(x, y, heading);
			
			/*
			 * CASE 1: Falling to wall distance
			 * 		   means end of block
			 * 
			 * 		   Find previous position that we saw the wall in
			 * 		   Or if there are none the object is occurring from the start of the scan
			 * 		   
			 */
			if(Math.abs(currentUS - wallDistance) < 10 ) {
				if(i == 0) {
					RConsole.println("xOF " + String.valueOf(x));
					grid.setTilesScan(start, x, y, previousUS, heading);
					
				} else {
					
					for(int j = i-4; j-3>0;j-=4) {
						RConsole.println("CASE1b");
						if(peaks.get(j) == 255 && Math.abs(peaks.get(j+1) - grid.distanceToWall(x, peaks.get(j+3), heading)) < 10) {
							grid.setTilesScan(peaks.get(j+2), x-2, y, 255, heading);
							break;
						} else if(Math.abs(peaks.get(j+1) - grid.distanceToWall(x, peaks.get(j+3), heading)) < 10) {
							grid.setTilesScan(peaks.get(j+2), x-2, y, previousUS, heading);
							break;
						}
					}
					
				}
				
				//Clear remaing tiles of scan
				if(i+3 == peaks.size()) {
					grid.setTilesScan(x-5, end, y, wallDistance, heading);
				}
				
			}
			
			/*
			 * CASE 2: we are not ending at the wall distance 
			 * 		   block remainder of scan
			 */
			else if (i+4 == peaks.size()) {
				RConsole.println("Last peak");
				grid.setTilesScan(x, end, y, currentUS, heading);
			}
			
			/*
			 * CASE 2: Rise to 255 
			 * 		   from wall distance
			 */
			else if (currentUS == 255 && Math.abs(previousUS - wallDistance) < 10) {
			
				for(int j = i-4; i-3>0;i-=4) {
					
					if(Math.abs(peaks.get(j) - wallDistance) < 10) {
						grid.setTilesScan(peaks.get(j+2), x, y, previousUS, heading);
						break;
					}
				}
			}
			
			
						
			
			
		}
	}
	
	public void inspectClosestTile( short tileValue) {
		int[] tile = {(int)odo.getX(), (int)odo.getY()};
		
		if( grid.getClosestTile(tile, tileValue) ) {
			nav.travelToTile(tile[0], tile[1]-1);
			//nav.turnTo(90);
			ort.inspect(tileValue, tile[0], tile[1]);
		}
	}
	
	
	public void checkPoints() {
		if(points.size() > 0) {
			odo.getNavigation().travelTo(points.get(0), points.get(1) - 12);
			odo.getNavigation().turnTo(90);
			RConsole.println("Checking Point 1");
			ort.start();
		}
		
	}
	
	
	
	public static String printArray(int[] array) {
		String result = "";
		for(int i=0; i<array.length; i++) {
			result += String.valueOf(array[i] + ",");
		}
		
		return result;
	}
	
	
	
}
