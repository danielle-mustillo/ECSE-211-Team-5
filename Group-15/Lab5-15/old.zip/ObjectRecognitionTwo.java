import lejos.nxt.ColorSensor;
import lejos.nxt.Sound;
import lejos.nxt.comm.RConsole;
import lejos.util.Timer;
import lejos.util.TimerListener;


public class ObjectRecognitionTwo implements TimerListener {

	private ColorSensor ls;
	private UltrasonicPoller usPoller;
	private TwoWheeledRobot robot;
	private LCDInfo display;
	private Navigation nav;
	private Odometer odo;
	private Timer oroTimer;
	private int lastUSValue;
	private boolean objectDetected;
	private Grid grid;

	private LCDInfo.BlockType object;
	private int lsCalibration = -1;
	private boolean typeDetected = false;
	private boolean detecting = false;
	private boolean haveStyrofoam = false;
	private boolean inspecting = false;
	
	public ObjectRecognitionTwo(ColorSensor ls, UltrasonicPoller usPoller, TwoWheeledRobot robot, LCDInfo display, Odometer odo) {
		this.ls = ls;
		this.usPoller = usPoller;
		this.robot = robot;
		this.display = display;
		this.lastUSValue = 256;
		this.objectDetected = false;
		this.oroTimer = new Timer(40, this);
		this.odo = odo;
		this.nav = odo.getNavigation();
		Sound.setVolume(60);
	}
	
	public void setGrid(Grid grid) {
		this.grid = grid;
	}
	
	public void timedOut() {
		
		if(ls.getFloodlight() != 0) {
			ls.setFloodlight(0);
			
			while(ls.getRawLightValue() == -1) {
				try { Thread.sleep(50); } catch (InterruptedException e) {}
			}
		}
		
		else if(lastUSValue < 256) {
			int newUSValue = usPoller.filterUS();
			
			if(objectDetected) {
				if(newUSValue > 40) {
					objectDetected = false;
					//display.blockDetected(false);
					//display.type(LCDInfo.BlockType.NONE);
					typeDetected = false;
					robot.setSpeeds(0, 0);
					stop();
				} else if(!typeDetected) {
					
					int lsValue = ls.getRawLightValue();
					//RConsole.println("ls: " + String.valueOf(lsValue));
					if(lsValue-lsCalibration < 5) {
						robot.setSpeeds(2.5,0);
					} else if(lsValue-lsCalibration < 40) {
						robot.setSpeeds(1.5, 0);
					} else {
						robot.setSpeeds(0, 0);
						
						oroTimer.stop();
						
						int redValue = lsValue;
					
						ls.setFloodlight(2);
											
						while(ls.getRawLightValue() == -1) {
							try { Thread.sleep(50); } catch (InterruptedException e) {}
						}
						
						int blueValue = ls.getRawLightValue();
						
						RConsole.println("Blue Value: " + String.valueOf(blueValue));
						if (redValue - blueValue > 25) {
							//object = LCDInfo.BlockType.WOOD;
							Sound.beep();
							Sound.buzz();
							grid.setTile(grid.getTileIndexWidth((int)odo.getX()), grid.getTileIndexLength((int) odo.getY()+12), (short) 1);
							RConsole.println("Wood");
							RConsole.println(grid.printGrid());
							nav.turnTo(90);
							nav.backup(10);
						} else {
							//object = LCDInfo.BlockType.STYROFOAM;
							Sound.beep();
							haveStyrofoam = true;
							capture();
							
						}
						
						//display.type(object);
						
						ls.setFloodlight(0);
						
						while(ls.getRawLightValue() == -1) {
							try { Thread.sleep(50); } catch (InterruptedException e) {}
						}						
						typeDetected = false;
						inspecting = false;
						detecting = false;
						
					}
				}
			}
			
			else if(newUSValue < 40) {
				//RConsole.println("Object Detected");
				objectDetected = true;
				display.blockDetected(true);
			}
			
		} else {
			lastUSValue = usPoller.filterUS();
			
		}
	}
	
	public void start() {
		detecting = true;
		usPoller.start();
		//lsPoller.start();
		ls.setFloodlight(0);
		while (lsCalibration < 0) {
			lsCalibration = ls.getRawLightValue();
			try { Thread.sleep(50); } catch (InterruptedException e) {}
		}
		oroTimer.start();

	}
	
	public void stop() {
		oroTimer.stop();
	}
	
	public void inspect(short tileValue, int i, int j) {
		
		inspecting  = true;
		nav.turnTo(90);
		usPoller.rotateUS(80);
		while(inspecting) {
			RConsole.println("running");
			int angleAValue;
			int angleBValue;
			int angleCValue;
			nav.turnTo(50);
			usPoller.rotateUS(90);
			
			angleAValue = usPoller.scan();
			nav.turnTo(90);
			usPoller.rotateUS(90);
			angleBValue = usPoller.scan();
			nav.turnTo(130);
			usPoller.rotateUS(110);
			angleCValue = usPoller.scan();
			
			if(tileValue == 7 || tileValue == 8) {
				int edgeOfTile = grid.getY(j) - (int) odo.getY() + 15;
				if(angleAValue > edgeOfTile &&  angleBValue > edgeOfTile && angleCValue > edgeOfTile) {
					grid.setTile(i, j, (short) 0);
					return;
				} 
			}
			
			int x = (int) odo.getX();
			if(angleCValue - angleAValue > 10 && Math.abs(angleAValue - angleBValue) > 5) {
				x += 10;
			} else if (angleCValue - angleAValue < 10 && Math.abs(angleAValue - angleBValue) > 5) {
				x -= 10;
			}
			
			RConsole.println("angleA " + String.valueOf(angleAValue));
			RConsole.println("angleB " + String.valueOf(angleBValue));
			RConsole.println("angleC " + String.valueOf(angleCValue));
			
			nav.travelTo(x, odo.getY());
			nav.turnTo(90);
			usPoller.rotateUS(80);
			
			if(usPoller.scan() < 40) {
				nav.travelTo(odo.getX(), odo.getY() + usPoller.scan()/2 );
				nav.turnTo(90);
				usPoller.rotateUS(75);
				start();
				
				while(detecting) {
					try{
						Thread.sleep(200);
					} catch(Exception e) {
						
					}
				}
			}
			
			
		}
		
		
	}
	
	public boolean getHaveStyrofoam() {
		return haveStyrofoam;
	}
	
	public void capture() {
		nav.turnTo(180);
		nav.travelToTile(3, 7);
	}
	
}
