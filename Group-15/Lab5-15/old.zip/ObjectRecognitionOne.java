import lejos.nxt.ColorSensor;
import lejos.nxt.comm.RConsole;
import lejos.util.Timer;
import lejos.util.TimerListener;


public class ObjectRecognitionOne implements TimerListener {

	private ColorSensor ls;
	private UltrasonicPoller usPoller;
	private TwoWheeledRobot robot;
	private LCDInfo display;
	private Timer oroTimer;
	private int lastUSValue;
	private boolean objectDetected;

	private LCDInfo.BlockType object;
	private int lsCalibration = -1;
	private boolean typeDetected = false;
	
	public ObjectRecognitionOne(ColorSensor ls, UltrasonicPoller usPoller, TwoWheeledRobot robot, LCDInfo display) {
		this.ls = ls;
		this.usPoller = usPoller;
		this.robot = robot;
		this.display = display;
		this.lastUSValue = 256;
		this.objectDetected = false;
		this.oroTimer = new Timer(40, this);
		ls.setFloodlight(0);
	}
	
	public void timedOut() {
		if(lastUSValue < 256) {
			int newUSValue = usPoller.filterUS();
			//RConsole.println("us: " + String.valueOf(newUSValue));
			if(objectDetected) {
				if(newUSValue > 40) {
					objectDetected = false;
					display.blockDetected(false);
					display.type(LCDInfo.BlockType.NONE);
					typeDetected = false;
					robot.setSpeeds(0, 0);
				} else if(!typeDetected) {
					
					int lsValue = ls.getRawLightValue();
					//RConsole.println("ls: " + String.valueOf(lsValue));
					if(lsValue-lsCalibration < 5) {
						robot.setSpeeds(6,0);
					} else if(lsValue-lsCalibration < 10) {
						robot.setSpeeds(3, 0);
					} else if(lsValue-lsCalibration < 20) {
						robot.setSpeeds(1.5, 0);
					} else {
						robot.setSpeeds(0, 0);
						
						oroTimer.stop();
						
						int redValue = lsValue;
					
						ls.setFloodlight(2);
											
						while(ls.getRawLightValue() == -1) {
							try { Thread.sleep(50); } catch (InterruptedException e) {}
						}
						
						int blueValue = ls.getRawLightValue();
						
						RConsole.println("Blue Value: " + String.valueOf(blueValue));
						if (redValue - blueValue > 25) {
							object = LCDInfo.BlockType.WOOD;
						} else {
							object = LCDInfo.BlockType.STYROFOAM;
						}
						
						display.type(object);
						
						ls.setFloodlight(0);
						
						while(ls.getRawLightValue() == -1) {
							try { Thread.sleep(50); } catch (InterruptedException e) {}
						}						
						typeDetected = true;
						oroTimer.start();
						
					}
				}
			}
			
			else if(newUSValue < 30) {
				//RConsole.println("Object Detected");
				objectDetected = true;
				display.blockDetected(true);
			}
			
		} else {
			lastUSValue = usPoller.filterUS();
			
		}
	}
	
	public void start() {
		usPoller.start();
		//lsPoller.start();
		ls.setFloodlight(0);
		while (lsCalibration < 0) {
			lsCalibration = ls.getRawLightValue();
		}
		oroTimer.start();

	}
	
	public void stop() {
		oroTimer.stop();
	}
	
	/*private void setFloodLight(int color) {
		ls.setFloodlight(color);		
		
		while (ls.getRawLightValue() == -1) {
			try {
				Thread.sleep(250);
			} catch (Exception e) {
			}
		}
	}*/
	
	
}
